

Additional Plugins Used
- dayjs - (Used for date format)
- cypress-mochawesome-reporter - (Used for Reporter)


PreReq 
 - Cypress installed

How to run test
- Download and extract the zip folder
- Navigate to folder using cmd / terminal / visual code IDE
- Run command 'npx cypress run'

The above command will run test spec files and once the execution is completed - Test Report can be accessed inside report folder.


Additional Information
- Test spec file is located under cypress/integration/tests/ folder test-1.js
- Generic functions located under cypress/support/commands.js
- Test data location under cypress/fixtures/
- Create account has been set skip - Manually created account

Addional Commands
- To run headless (npx cypress run)
- To run using GUI (npx cypress open)
