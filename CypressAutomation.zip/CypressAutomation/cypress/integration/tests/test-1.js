var dayjs = require('dayjs')

describe('Test 1 - Web Application', () => {

    before(function () {
        //Visit application URL
        cy.visit(Cypress.env('app_url'))
    })
    beforeEach(() => {
        cy.visit(Cypress.env('app_url'))
        //Sign In
        cy.signin()
    })


    it.skip('Create Account', () => {

        cy.fixture('creds').then(function (creds) {
            this.creds = creds
            cy.signup(this.creds.email,this.creds.password)
        })
          
    })

    it('Verify Account', () => {

        //Verify Email
        cy.fixture('creds').then(function (creds) {
            this.creds = creds
            cy.get('.navbar-text').should('have.text', this.creds.email)
        })
        
    })


    it('Create New Valid Address & Verify', () => {

        //Navigate to Address
        cy.address_page()
        
        //Click New Address
        cy.new_address()

        //Fill Form Everything
        cy.fixture('addresses').then(function (addresses) {
            this.addresses = addresses
                cy.add_address(
                    this.addresses.firstname,this.addresses.lastname,this.addresses.address1,this.addresses.address2,this.addresses.city
                    ,this.addresses.state,this.addresses.zipcode,this.addresses.country,this.addresses.bday,this.addresses.age,this.addresses.website
                    ,'profile.jpeg',this.addresses.phone,this.addresses.note
                )

                //Submit
                cy.get('[data-test=submit]').click()

                //Verify Address
                cy.verify_address(
                    this.addresses.firstname,this.addresses.lastname,this.addresses.address1,this.addresses.address2,this.addresses.city
                    ,this.addresses.state,this.addresses.zipcode,this.addresses.country,this.addresses.bday,this.addresses.age,this.addresses.website
                    ,this.addresses.phone,this.addresses.note
                )
            })
    })

    it('Verify Editing Address Form', () => {

        //Navigate to Address
        cy.address_page()
        
        //Click Edit Link
        cy.edit()
            
        //Verify Editing Form is Loaded
        cy.contains('Editing Address').should('be.visible')

        //Verify Addresses on Edit Form
        cy.fixture('addresses').then(function (addresses) {
            this.addresses = addresses
            //Verify Address from Edit From
            cy.verify_address_edit_form(
                this.addresses.firstname,this.addresses.lastname,this.addresses.address1,this.addresses.address2,this.addresses.city
                    ,this.addresses.zipcode,this.addresses.country,this.addresses.bday,this.addresses.age,this.addresses.website
                    ,this.addresses.phone,this.addresses.note,this.addresses.state
            )
        })

    })

    it('Update Address - First Name', () => {

        //Navigate to Address
        cy.address_page()
        
        //Click Edit Link
        cy.edit()

        //Update First Name
        cy.update_address('Test First Name 1 - Updated')
    
    })

    it('Verify Updated Address - First Name', () => {

        //Navigate to Address
        cy.address_page()
        
        //Verify Table - First Name
        cy.get('table').contains('td', 'Test First Name 1 - Updated');
        
    })

    it('Create Second Address Without First Name & ZIPCODE', () => {

        //Navigate to Address
        cy.address_page()
        
        //Click New Address
        cy.new_address()
 
        //Fill Form
        cy.fixture('addresses').then(function (addresses) {
            this.addresses = addresses
                cy.add_address(
                     this.addresses.firstname2,this.addresses.lastname2,this.addresses.address12,this.addresses.address22,this.addresses.city2
                     ,this.addresses.state2,this.addresses.zipcode,this.addresses.country2,this.addresses.bday2,this.addresses.age2,this.addresses.website2
                     ,'profile.jpeg',this.addresses.phone2,this.addresses.note2
                )
        })

        //Remove First Name and ZIPCODE
        cy.get('#address_first_name').click({ force: true })
        cy.get('#address_first_name').clear()
        cy.get('#address_zip_code').click({ force: true })
        cy.get('#address_zip_code').clear()

        //Submit
        cy.get('[data-test=submit]').click()
        
        //Verify Error Message
        cy.get('ul > :nth-child(1)').should('have.text', "First name can't be blank")
        cy.get('ul > :nth-child(2)').should('have.text', "Zip code can't be blank")

    })

    it('Create Second Address Without Error', () => {

        //Navigate to Address
        cy.address_page()
        
        //Click New Address
        cy.new_address()
  
        //Fill Form
        cy.fixture('addresses').then(function (addresses) {
             this.addresses = addresses
                 cy.add_address(
                      this.addresses.firstname2,this.addresses.lastname2,this.addresses.address12,this.addresses.address22,this.addresses.city2
                      ,this.addresses.state2,this.addresses.zipcode,this.addresses.country2,this.addresses.bday2,this.addresses.age2,this.addresses.website2
                      ,'profile.jpeg',this.addresses.phone2,this.addresses.note2
                 )
        })

        //Submit
        cy.get('[data-test=submit]').click()


    })

    it('Verify Address Lists', () => {

        //Navigate to Address
        cy.address_page()
        //Verify Address Table Has Only TWO Rows
        cy.get('tbody').find('tr').should('have.length', 2)

    })

    it('Remove Address From List & Verify', () => {

        //Navigate to Address
        cy.address_page()

        cy.get('tbody>tr').each(($el, index, $list) => {
            //Click Detstroy Button
            cy.contains('Destroy').click()
        })

        //Verify Address Table Has No Records
        cy.get('tbody').find('tr').should('have.length', 0)
    })

})