import 'cypress-file-upload';
var dayjs = require('dayjs')

//Sign Up
Cypress.Commands.add('signup', (email,password) => {

    //Click sign In
    cy.get('[data-test=sign-in]').click()

    //Click Sign Up
    cy.get('[data-test=sign-up]').click()

    cy.fixture('creds').then(function (creds) {
    this.creds = creds
        //Enter Email
        cy.get('input[type="email"]').click({ force: true })
        cy.get('input[type="email"]').type(this.creds.email, { force: true })
        //Enter Password
        cy.get('input[type="password"]').type(this.creds.password)
        //Submit
        cy.get('[data-test=submit]').click()
    })
})

//Sign In
Cypress.Commands.add('signin', (email,password) => {

    //Click sign In
    cy.get('[data-test=sign-in]').click()

    cy.fixture('creds').then(function (creds) {
    this.creds = creds
        //Enter Email
        cy.get('input[type="email"]').click({ force: true })
        cy.get('input[type="email"]').type(this.creds.email, { force: true })
        //Enter Password
        cy.get('input[type="password"]').type(this.creds.password)
        //Submit
        cy.get('[data-test=submit]').click()
    })
})

//Add Address
Cypress.Commands.add('add_address', (fname,lname,add1,add2,city,state,zipcode,country,bday,age,website,filename,phone,note) => {
    //Enter Form Details
    cy.get('#address_first_name').click({ force: true })
    cy.get('#address_first_name').type(fname, { force: true })
    cy.get('#address_last_name').type(lname)
    cy.get('#address_street_address').type(add1)
    cy.get('#address_secondary_address').type(add2)
    cy.get('#address_city').type(city)
    //cy.get('#address_state').select(state)
    cy.get('select').select(state)
    cy.get('#address_zip_code').type(zipcode)
    cy.get('[type="radio"]').check(country)
    cy.get('input[type=color]').invoke('val', '#ff0000').trigger('change')
    cy.get('#address_birthday').type(bday)
    cy.get('#address_age').type(age)
    cy.get('#address_website').type(website)
    const filepath = filename
    cy.get('input[type="file"]').attachFile(filepath)
    cy.get('#address_phone').type(phone)
    cy.get('#address_interest_read').click()
    cy.get('#address_note').type(note)
})

//Verify Addresses
Cypress.Commands.add('verify_address', (fname,lname,add1,add2,city,state,zipcode,country,bday,age,website,phone,note) => {
    //Verify Success Message
    cy.contains('[data-test=notice]', 'Address was successfully created.')
    //Verify Address
    cy.get('[data-test=first_name]').should('have.text', " "+fname)
    cy.get('[data-test=last_name]').should('have.text',  " "+lname)
    cy.get('[data-test=street_address]').should('have.text',  " "+add1)
    cy.get('[data-test=secondary_address]').should('have.text', " "+add2)
    cy.get('[data-test=city]').should('have.text', " "+city)
    cy.get('[data-test=state]').should('have.text', " "+state)
    cy.get('[data-test=zip_code]').should('have.text', " "+zipcode)
    cy.get('[data-test=country]').should('have.text', " "+country)
    cy.get('[data-test=birthday]').should('have.text', " "+dayjs(bday).format('M/DD/YYYY'))
    cy.get('[data-test=age]').should('have.text', " "+age)
    cy.get('[data-test=website]').should('have.text', " "+website)
    cy.log(formatPhNo(phone))
    cy.get('[data-test=phone]').should('have.text', " "+formatPhNo(phone))
    cy.get('[data-test=note]').should('have.text', note)
})

//Verify Editing Address Form
Cypress.Commands.add('verify_address_edit_form', (fname,lname,add1,add2,city,zipcode,country,bday,age,website,phone,note,state) => {
    
    //Verify Address from Edit Form
    cy.get('#address_first_name').should('have.value', fname)
    cy.get('#address_last_name').should('have.value', lname)
    cy.get('#address_street_address').should('have.value', add1)
    cy.get('#address_secondary_address').should('have.value', add2)
    cy.get('#address_city').should('have.value', city)
    cy.get('#address_zip_code').should('have.value', zipcode)
    cy.get('#address_country_us').should('be.checked').and('have.value', country)
    cy.get('#address_birthday').should('have.value', bday)
    cy.get('#address_age').should('have.value', age)
    cy.get('#address_website').should('have.value', website)
    cy.get('#address_phone').should('have.value', phone)
    cy.get('#address_interest_read').should('be.checked')
    cy.get('#address_note').should('have.value', note)
    cy.get('#address_state').should('have.value', state)
   
    
})

//Format Telephone Number
function formatPhNo(no) {
    return no = no.replace(/-/g,"").replace(/^(?=[0-9]{11})([0-9]{4})([0-9]{3})([0-9]{4})$/, "$1-$2-$3");
}
//Navigate to Address Page
Cypress.Commands.add('address_page',() => {
    cy.get('a[href*="/addresses"]').click()
})

//Click a Link Button
Cypress.Commands.add('edit',() => {
    cy.contains('Edit').click()
})

//Click List Button
Cypress.Commands.add('list',() => {
    cy.contains('List').click()
})

//Click New Address Button
Cypress.Commands.add('new_address',() => {
    cy.get('a[href*="/addresses/new"]').click()
})

//Update Address
Cypress.Commands.add('update_address',(fname) => {
    //Update Address First Name
    cy.get('#address_first_name').click({ force: true })
    cy.get('#address_first_name').clear()
    cy.get('#address_first_name').type(fname)

    cy.wait(500)
    //Submit
    cy.get('[data-test=submit]').click()
    cy.wait(500)
})